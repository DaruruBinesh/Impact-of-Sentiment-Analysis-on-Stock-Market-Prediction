import tweepy
from tweepy import OAuthHandler
from textblob import TextBlob
import re
from TWLocation import tweetlocation
import numpy as np
import matplotlib.pyplot as plt
import sys

class TwitterClient(object):
    

    def __init__(self):
        
        
        consumer_key = 'RX1TfloBW5z32QGbWalCI8HXE'
        consumer_secret = 'izfNCz9LMwHVVWTtqIWwtN3PQHpdFySPV802sHKjLeypxHSRW6'
        access_token = '1198600156523847681-Foy5c01lD7Hwnt3WTteiuo6iqmLISA'
        access_token_secret = 'o3eX3XO1KOUpx2qniMcKpBzz0d5v5qlHQG5Qqnvyc4Pvi'

        
        try:
            
            self.auth = OAuthHandler(consumer_key, consumer_secret)
            
            self.auth.set_access_token(access_token, access_token_secret)
            
            self.api = tweepy.API(self.auth)
        except:
            print("Error: Authentication Failed")

    def clean_tweet(self, tweet):
       
        return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t])| (\w+:\ / \ / \S+)", " ", tweet).split())

    def get_tweet_sentiment(self, tweet):
       
        
        analysis = TextBlob(self.clean_tweet(tweet))
    
        if analysis.sentiment.polarity > 0:
            return 'positive'
        elif analysis.sentiment.polarity == 0:
            return 'neutral'
        else:
            return 'negative'

    def get_tweets(self, query, count=10):
        
        
        tweets = []
        try:
            
            fetched_tweets = self.api.search(q=query, count=count)
            
            for tweet in fetched_tweets:
                
                tweet_str = str(tweet)
                parsed_tweet = {}
                
                parsed_tweet['text'] = tweet.text
                
                parsed_tweet['sentiment'] = self.get_tweet_sentiment(tweet.text)

                
                if tweet.retweet_count > 0:
                    
                    if parsed_tweet not in tweets:
                        tweets.append(parsed_tweet)
                else:
                    tweets.append(parsed_tweet)

            
            return tweets

        except tweepy.TweepError as e:
            
            print("Error : " + str(e))


def graphing(objects, percentages):
    y_pos = np.arange(len(objects))
    plt.bar(y_pos, percentages, align='center', alpha=0.5)
    plt.xticks(y_pos, objects)
    plt.ylabel('Percent')
    plt.title('Emotions')
    plt.show()


def main():
    
    api = TwitterClient()

    person = input("Enter the User Name or Trend:\t")
    tweets = api.get_tweets(query=person, count=200)

    ptweets = [tweet for tweet in tweets if tweet['sentiment'] == 'positive']
    
    postive_tweet_percentage = 100 * len(ptweets) / len(tweets)
    print("Positive tweets percentage: {} %".format(postive_tweet_percentage))
    
    ntweets = [tweet for tweet in tweets if tweet['sentiment'] == 'negative']
    
    negative_tweet_percent = 100 * len(ntweets) / len(tweets)
    print("Negative tweets percentage: {} %".format(negative_tweet_percent))
    
    nutweets = [tweet for tweet in tweets if tweet['sentiment'] == 'neutral']
    
    neutral_tweet_percent = 100 * (len(tweets) - len(ntweets) - len(ptweets)) / len(tweets)
    print("Neutral tweets percentage: {} % \
          ".format(neutral_tweet_percent))

    
    print("\n\nPositive tweets:")
    for tweet in ptweets[:10]:
        print(tweet['text'])

    
    print("\n\nNegative tweets:")
    for tweet in ntweets[:10]:
        print(tweet['text'])

    
    print("\n\nNeutral tweets:")
    for tweet in nutweets[:10]:
        print(tweet['text'])

    objects = ('Positve', 'Negative', 'Neutral')
    percentage = [postive_tweet_percentage, negative_tweet_percent, neutral_tweet_percent]

    graphing(objects, percentage)

    cal_tweet_location = input("Do yo want to know the tweet the Person is attending [y/n] :\t")
    if cal_tweet_location == 'y':
        tweetlocation()
    else:
        print(' code complexted')
        sys.exit(0)


if __name__ == "__main__":
    
    main()
